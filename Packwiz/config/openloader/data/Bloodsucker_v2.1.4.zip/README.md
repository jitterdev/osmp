# Powers
[+] Vampirism
You don't naturally exhaust, and food provides no benefit. Instead of eating, you can feed from mobs by 
Sneak+Right-Clicking them from behind, damaging them and providing you with food.
Sucking the blood of a mob gives it the Vampiric Mark, providing the following effects:
 - Slightly extends the mark's duration when hit
 - Gives attacking Bloodsuckers more food
 - Multiplies taken damage by 1.5x

[+] Batty Behavior
You can transform into a bat while above 3 food shanks. To transform, activate creative flight.
While transformed:
 - You can slowly move freely through the air
 - You're shorter than a block
 - You rapidly exhaust
 - You have 5 hearts
 - You cannot attack or use items

[+] Vampiric Regeneration
You do not regenerate normally, but you'll rapidly regenerate at the cost of food. Every food shank can heal up to 5 hearts before being depleted.

[+] Ghoulish Endurance
You have 3 extra hearts, and the ability to sacrifice food for health instead of dying, as long as your killer wasn't using a wooden sword.

[+] Bloodsucking Leftovers
You can sacrifice health, and food to fill a glass bottle with your blood by right clicking the air with an Athame. Target other creatures by sneaking and right-clicking their back with an Athame.

[+] Blood Chemistry
You can augment blood vials in your inventory by right-clicking them with an ingredient in your cursor.
 * Use a blood vial on an identical blood vial to create a concentrated vial, which has 1.5x the effects.
 * Use certain ingredients on red blood vials to change their blood type to one that corresponds with the ingredient.
 * Use a golden apple on a Concentrated Bloodsucker blood vial to turn it into Golden Blood, which is nearly as powerful as enchanted golden apples.

[-] Heliophobia
When exposed to sunlight, you will take 2x damage, and exhaust over time.
 * If you're unable to sprint, the sun will do damage over time. If you're starving, the sun will light you on fire.
 * Disabled by the following:
   - Invisibility
   - Fire Resistance
   - Leather Helmet (at the cost of durability)
   - Water, Ice, Snow

[-] Unholy
Your intrinsic unholiness means being hurt by fire, or a smite-infused weapon will hurt more and disable your regeneration capabilities for 10 seconds.
------------------------------------------------------------------
Main Designer:
    Silent#7718
    
# Changelog v2.1.4
- Target dummies from MmmMmmMmmMmm can no longer have their blood sucked
- Increased drain from sunlight
- Reduced drain on leather helmets in sunlight
- Increased damage from Smite