# Kindling | Impact: 3
The Kindling is a lesser fire spirit born from the sparks of the powerful Hell Forges in the fiery Nether.

[=] **Arcane Flame**
    You do not exhaust. Instead you have a Heat meter which affects your other powers.
[Info]: 
    To increase Heat, consume fuel, hot items, or ignition items by 
    Sneak+Right-Clicking.
[Info]:
    Heat slowly depletes unless on fire, or you can drink water to extinguish yourself.

[=] **Nether Inhabitant**
    Your natural spawn will be in the Nether.

[+] **Fire Immunity**
    You are immune to all types of fire damage.

[+] **Flaming Dash** [Primary]
    You can dash in any direction, damaging nearby mobs and consuming fuel while launching you forward.

[+] **Overheat**
    Consuming high energy fuel with full Heat will overheat you, making you lose fuel to gain health.

[=] **Crackling Fuel**
    If you take damage after overheating, you lose Heat and hurt nearby targets.

[-] **Firestarter**
    While overheating, you occasionally ignite the block you're standing on.

[-] **Fire's Bane**
    Water extinguishes you, causing you to take damage and lose Heat while wet. Snowballs deal true damage to you.

[=] **Burnout**
    You become extinguished when your Heat meter is empty, gaining various buffs and debuffs.

[-] **Heart of Flame**
    Made of pure heat and fuel, you cannot eat and you do not naturally regenerate Health.

[-] **Ancraophobia**
    You cannot stand high winds or avoid burning Elytra, so you cannot wear them.
-------------------------------------------------
Main Designer:
    Bemoseemo#2365
Developer, Co-Designer:
    Silent#7718
    
# Changelog v0.1.4
- Fixed credits power to credit bemo and not apace (whoops)
- Fixed resource bars for consuming heat and losing heat being wrong