# Gelatinous
The Gelatinous are a race of slime-like creatures known best for their flexibility in appearance, and ability.

[+] **Bouncy**
    You jump very high, and you take and deal more knockback. You're immune to fall damage, and bounce from landing.
[Info]: You do not bounce while sneaking, sprinting, or jumping.

[+] **Malleable**
    You cannot lose more than 50% of your current health at a time.

[+] **Slimy Body**
    You are immune to toxins, and status effects that are incompatible with your slimy body.
[Info]: Effects Nullified
 - Poison
 - Hunger
 - Wither
 - Regeneration

[+] **Gooey Mass**
    You have a Mass meter. The majority of your stats, whether beneficial or not, are proportional to your current mass.
[Info]: **Affected Stats**
 - Size
 - Maximum Health
 - Movement Speed
 - Attack Damage/Speed
 - Step Height

[+] **Sticky Arms**
    While at or below 40 mass, you are able to climb walls like ladders.

[+] **Energy Consumption**
    You exhaust 30% less, and 60% less while small.\nYou get more from food while smaller, but less while bigger.

[+] **Mass Ejection**
    You can use your Primary to eject some of your mass, giving you a slimeball at the cost of mass.

[+] **Mass Absorption**
    You can absorb slime balls into your body to increase your mass. Eating while full slightly increases your mass.
[Info]: Eating slimeballs heals you slightly, and usually restores enough mass to increase your max health.
[Info]: You take double damage for 3 seconds after absorbing or ejecting slimeballs.

[+] **Slimed**
    Killing enemies will have a 1/4 chance to award 1-2 slimeballs.

[-] **Mass Extermination**
    When you take damage, you'll randomly lose mass roughly equivalent to the damage taken.
[Info]: For every half-heart you lose, you will lose the following mass: 75% for 1, 50% for 2, 25% for 3

[-] **Mass Decay**
    While you have more than 25% mass, you'll lose mass instead of food when you exhaust.

```
Changelog
------------------------------------------------------------------
- Fixed oversight in Mass Ejection description...
------------------------------------------------------------------
```