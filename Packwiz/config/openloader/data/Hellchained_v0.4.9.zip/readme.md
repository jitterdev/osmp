**Hellchained** Requires the latest origins version!
A forsaken, brutish mastermind banished to Hell by the Divine for practicing forbidden soul magic.

[-] **Hellbound**
    You have been banished to the Nether as a punishment from the Divine. You spawn in the Nether, and can't enter Nether Portals.

[+] **Soul Harvesting**
    You can kill mobs for a chance to absorb their soul through forbidden magic, storing it in your Soul Bar.
[Info]: The amount of soul energy you get per kill is random, and dependent on how powerful the mob is.

[+] **Astral Projecting**
    With forbidden magic, you can manifest your Soul into the overworld, crossing dimensions in another form. This ability requires, and slowly consumes stored souls.
[Info]: When manifested, you will be in your Soul Form, and unable to enter the Nether through normal means.
[Info]: When manifested, your souls will slowly drain. You will be teleported out of the nether if you run out.
[Info]: When manifested, other creatures can teleport to your soul by entering your body's location.

## Bound

[+] **Heavy Acrobatics** (Bound Form)
    With your special physique you're immune to fall damage, and falling from high distances unleashes an AoE attack.

[+] **Strider Technique** (Bound Form)
    Your webbed, heat-resistant feet let you walk on lava, and you're immune to it.

[+] **Soul Speed** (Bound Form)
    You can walk nearly like normal on soul sand due to your arched, hoof-like feet.

[+] **Fire Tolerant** (Bound Form)
    You take 50% less fire-related damage.

[+] **Dark-Green Thumb** (Bound Form)
    You can Sneak+Right-Click a mushroom in its optimal habitat to bonemeal it at the cost of some exhaustion.

[+] **Refined Senses** (Bound Form)
    You can see nearby mobs, and projectiles through walls.

## Soul

[-] **Crying Purple** (Soul Form)
    Crying obsidian is a natural repellant to your magic. When near crying obsidian, you'll be debuffed.
[Info]: Debuffs include:
- You quickly lose souls
- You deal less damage
- You mine slower
- You move slower
- You have an intrusive purple overlay

[-] **Fragile Form** (Soul Form)
    Your soul form is unstable and weak, and you have less health as a result.

[+] **Environmental Immunity** (Soul Form)
    Due to your incorporeal form, you are immune to most types of environmental damage.

[+] **Floaty Form** (Soul Form)
    You jump much higher, fall much slower, and get knocked back further.

[+] **Permeable** (Soul Form)
    You can walk through pressure plates, tripwires, doors, and other traps without affecting them.

[+] **Contingency Plan** (Soul Form)
    You can sacrifice your absorbed souls to save your life while in your soul form. If you would die without enough souls, you go back to your body instead.

# Changelog v0.4.9
- Fixed souls getting reset when you relog (this was surprisingly complicated)